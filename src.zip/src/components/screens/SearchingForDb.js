/* eslint-disable prettier/prettier */
import React from "react";
import { Text, View, StyleSheet,Image,ActivityIndicator,TouchableOpacity } from "react-native";
import Constants from "expo-constants";
import { AntDesign } from "@expo/vector-icons";
export const SearchingForDb = ()=>{
  return (
    <View style={styles.container}>
    <Image style={styles.logo} source={require("../../../assets/DeliveryBoy.jpg")} />
    <Text style={styles.paragraph}> Searching For {"\n"} Delivery Boy...</Text>
           <TouchableOpacity style={styles.btn}>
             <AntDesign name="closecircle" size={54} color="rgb(255,75,76)" />
            </TouchableOpacity>
            
            <ActivityIndicator size="large" animating={true} color="#1DC47A"/>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    paddingTop: Constants.statusBarHeight,
    backgroundColor: "white",
    padding: 8,
    alignItems:"center",
  },
  paragraph: {
    fontFamily:"QuickSand",
    margin: 24,
    fontSize: 18,
    textAlign: "center",

  },
  logo:{
    height:250,
    width:250,
    borderRadius:150,
  },
   btn: {
    position:"absolute",
    bottom:50,

  },
});
