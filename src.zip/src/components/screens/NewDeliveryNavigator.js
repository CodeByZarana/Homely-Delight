/* eslint-disable prettier/prettier */
import React from "react";
import {SetLocationScreen} from "../../components/screens/SetLocationScreen";
import { createStackNavigator } from "@react-navigation/stack";
import {ConfirmOrder} from "../../components/screens/ConfirmOrder";
import { Searching } from "../../components/screens/Searching";
import {MapScreen} from "./Mapscreen";
import {MapScreen2} from "./Mapscreen2";

const Stack = createStackNavigator();

export const NewDeliveryNavigator = () => {
  return (
      <Stack.Navigator  screenOptions={{
           header: () => null,
         }}>
        <Stack.Screen
          name="Set Location"
          component={SetLocationScreen}
        />
        <Stack.Screen name="mapscreen" component={MapScreen} />
        <Stack.Screen name="mapscreen2" component={MapScreen2} />
        <Stack.Screen name="co" component={ConfirmOrder} />
        <Stack.Screen name="Searching" component={ Searching } />
      </Stack.Navigator>
  );
};